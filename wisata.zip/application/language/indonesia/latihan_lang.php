<?php

$lang['title'] = 'Latihan Bahasa';
$lang['content'] = 'Ini adalah latihan membuat multiple language dengan Codeigniter ^_^';

?>