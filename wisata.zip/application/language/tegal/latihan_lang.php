<?php

$lang['title'] = 'Latihan nganggo Bahasa Jon';
$lang['content'] = 'Kyeh carane nganggo Language Class goneng Codeigniter, gampang men ow ya.. sih ndarani angel jon... nang kene kyeh..';

?>